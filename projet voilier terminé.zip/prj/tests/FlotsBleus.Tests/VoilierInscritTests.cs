using NUnit.Framework;
using FlotsBleus.Core;

namespace FlotsBleus.Tests
{
    [TestFixture]
    public class VoilierInscritTests
    {
        [Test]
        public void AjouterSponsor_AjouteEntreprise_ListeNonVide()
        {
            // Arrange
            VoilierInscrit voilier = new VoilierInscrit("code", "codeInscription");
            Entreprise sponsor = new Entreprise("Sponsor");

            // Act
            voilier.AjouterSponsor(sponsor);

            // Assert
            Assert.That(voilier.Sponsors, Contains.Item(sponsor));
        }

        [Test]
        public void SupprimerSponsor_SupprimeEntreprise_ListeVide()
        {
            // Arrange
            VoilierInscrit voilier = new VoilierInscrit("code", "codeInscription");
            Entreprise sponsor = new Entreprise("Sponsor");
            voilier.AjouterSponsor(sponsor);

            // Act
            voilier.SupprimerSponsor(sponsor);

            // Assert
            Assert.That(voilier.Sponsors, Does.Not.Contain(sponsor));
        }
    }
}
