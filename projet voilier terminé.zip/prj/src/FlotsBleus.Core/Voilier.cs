﻿namespace FlotsBleus.Core
{
    using System.Collections.Generic;

    public class Voilier
    {
        public string Code { get; set; }
        public List<Personne> Equipage { get; set; }

        public Voilier(string code)
        {
            Code = code;
            Equipage = new List<Personne>();
        }

        public void AjouterMembreEquipage(Personne membre)
        {
            Equipage.Add(membre);
        }

        public void SupprimerMembreEquipage(Personne membre)
        {
            Equipage.Remove(membre);
        }
    }
}
