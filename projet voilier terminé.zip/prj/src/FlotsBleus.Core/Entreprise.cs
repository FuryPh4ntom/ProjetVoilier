namespace FlotsBleus.Core
{
    public class Entreprise
    {
        public string Nom { get; set; }

        public Entreprise(string nom)
        {
            Nom = nom;
        }
    }
}
