using System.Collections.Generic;
using FlotsBleus.Core;

namespace FlotsBleus.Core
{
    public class VoilierInscrit : Voilier
    {
        public string CodeInscription { get; }
        public List<Entreprise> Sponsors { get; }

#pragma warning disable CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider adding the 'required' modifier or declaring as nullable.
        public VoilierInscrit(string code, string codeInscription) : base(code)
#pragma warning restore CS8618 // Non-nullable field must contain a non-null value when exiting constructor. Consider adding the 'required' modifier or declaring as nullable.
        {
            CodeInscription = codeInscription;
            Sponsors = new List<Entreprise>();
        }

        public void AjouterSponsor(Entreprise sponsor)
        {
            Sponsors.Add(sponsor);
        }

        public void SupprimerSponsor(Entreprise sponsor)
        {
            Sponsors.Remove(sponsor);
        }
    }
}
