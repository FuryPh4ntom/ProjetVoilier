namespace FlotsBleus.Core
{
    using System;
    using System.Collections.Generic;

    public class VoilierEnCourse : VoilierInscrit
    {
        public TimeSpan TempsBrut { get; set; }
        public TimeSpan TempsReel => TempsBrut - new TimeSpan(0, PenaltiesSum, 0); 
        private int PenaltiesSum { get; set; }

        public VoilierEnCourse(string code, string codeInscription) : base(code, codeInscription)
        {
        }

        public void AjouterPenalite(int penaliteMinutes)
        {
            PenaltiesSum += penaliteMinutes;
        }
    }
}
