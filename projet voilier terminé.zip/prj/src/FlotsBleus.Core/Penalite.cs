namespace FlotsBleus.Core
{
    public class Penalite
    {
        public TypeDePenalite Type { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }

        public Penalite(TypeDePenalite type, string latitude, string longitude)
        {
            Type = type;
            Latitude = latitude;
            Longitude = longitude;
        }
    }
}
