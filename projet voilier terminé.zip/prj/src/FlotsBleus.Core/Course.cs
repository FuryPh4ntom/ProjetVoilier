namespace FlotsBleus.Core
{
    using System.Collections.Generic;

    public class Course
    {
        public List<VoilierInscrit> VoiliersInscrits { get; set; }
        public List<VoilierEnCourse> VoiliersEnCourse { get; set; }
        public List<Epreuve> Epreuves { get; set; }

        public Course()
        {
            VoiliersInscrits = new List<VoilierInscrit>();
            VoiliersEnCourse = new List<VoilierEnCourse>();
            Epreuves = new List<Epreuve>();
        }

        public void AjouterVoilierEnCourse(VoilierEnCourse voilier)
        {
            VoiliersEnCourse.Add(voilier);
        }

        public void SupprimerVoilierEnCourse(VoilierEnCourse voilier)
        {
            VoiliersEnCourse.Remove(voilier);
        }

        public void AjouterEpreuve(Epreuve epreuve)
        {
            Epreuves.Add(epreuve);
        }
    }
}
