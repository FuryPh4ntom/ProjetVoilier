namespace FlotsBleus.Core
{
    public class TypeDePenalite
    {
        public string Code { get; set; }
        public int Duree { get; set; } // Durée en minutes

        public TypeDePenalite(string code, int duree)
        {
            Code = code;
            Duree = duree;
        }
    }
}
