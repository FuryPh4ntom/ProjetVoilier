namespace FlotsBleus.Core
{
    public class Personne
    {
        public string Nom { get; set; }
        public string Role { get; set; }

        public Personne(string nom, string role)
        {
            Nom = nom;
            Role = role;
        }
    }
}
