namespace FlotsBleus.Core
{
    public class Epreuve
    {
        public int Num { get; set; }
        public string Libelle { get; set; }
        public int Ordre { get; set; }

        public Epreuve(int num, string libelle, int ordre)
        {
            Num = num;
            Libelle = libelle;
            Ordre = ordre;
        }
    }
}
