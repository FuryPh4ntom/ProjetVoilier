﻿namespace FlotsBleus.ConsoleApp;
using System;
using FlotsBleus.Core;

    class Program
    {
        static void Main(string[] args)
        {
            // Création d'un voilier inscrit
            var voilier = new VoilierInscrit("VA102SETE", "C23VC1");

            // Ajout de sponsors
            var sponsor1 = new Entreprise("Sponsor1");
            var sponsor2 = new Entreprise("Sponsor2");
            voilier.AjouterSponsor(sponsor1);
            voilier.AjouterSponsor(sponsor2);

            // Affichage des sponsors
            Console.WriteLine($"Voilier {voilier.CodeInscription} a les sponsors suivants:");
            foreach (var sponsor in voilier.Sponsors)
            {
                Console.WriteLine($"- {sponsor.Nom}");
            }
        }
    }

